"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Home, ChevronRight, Heart, ChevronDown } from "lucide-react"
import { Header } from "@/components/museum/header"
import { Footer } from "@/components/museum/footer"

const products = [
  {
    id: 1,
    category: "외국인 선물",
    name: "호건 에어팟 프로 케이스",
    price: 30000,
    badges: ["MD추천"],
    image: "https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=600&h=600&fit=crop&q=80",
  },
  {
    id: 2,
    category: "외국인 선물",
    name: "이순신 전립 와인마개",
    price: null,
    badges: ["BEST", "MD추천"],
    image: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=600&h=600&fit=crop&q=80",
  },
  {
    id: 3,
    category: "외국인 선물",
    name: "나전 핸드워시 핸드크림 세트(단독 구매)",
    price: null,
    badges: ["BEST", "MD추천"],
    image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=600&h=600&fit=crop&q=80",
  },
  {
    id: 4,
    category: "외국인 선물",
    name: "일월오봉도 앞치마(단독 구매)",
    price: null,
    badges: [],
    image: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600&h=600&fit=crop&q=80",
  },
  {
    id: 5,
    category: "외국인 선물",
    name: "반가사유상 캐릭터 인형(78호)",
    price: null,
    badges: ["BEST", "MD추천"],
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=600&fit=crop&q=80",
  },
  {
    id: 6,
    category: "외국인 선물",
    name: "등롱 이순신 램프",
    price: null,
    badges: [],
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=600&h=600&fit=crop&q=80",
  },
  {
    id: 7,
    category: "외국인 선물",
    name: "나전 호랑이 손거울",
    price: null,
    badges: [],
    image: "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?w=600&h=600&fit=crop&q=80",
  },
  {
    id: 8,
    category: "외국인 선물",
    name: "백은배화접도 3단 자동우산_분홍색",
    price: null,
    badges: ["BEST"],
    image: "https://images.unsplash.com/photo-1534088568595-a066f410bcda?w=600&h=600&fit=crop&q=80",
  },
]

const sortOptions = [
  { value: "", label: "선택" },
  { value: "popular", label: "인기순" },
  { value: "newest", label: "최신순" },
  { value: "price-low", label: "낮은 가격순" },
  { value: "price-high", label: "높은 가격순" },
]

export default function ForeignGiftThemePage() {
  const [wishlist, setWishlist] = useState<number[]>([])
  const [sortBy, setSortBy] = useState("")
  const [isSortOpen, setIsSortOpen] = useState(false)

  const toggleWishlist = (id: number) => {
    setWishlist(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  const selectedSortLabel = sortOptions.find(opt => opt.value === sortBy)?.label || "선택"

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-6 pb-20">
        <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-1.5 text-[12px] text-muted-foreground mb-12">
            <Link href="/" className="hover:text-foreground transition-colors">
              <Home className="w-3.5 h-3.5" />
            </Link>
            <ChevronRight className="w-3 h-3" />
            <Link href="/theme" className="hover:text-foreground transition-colors">
              테마(굿즈픽)
            </Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground">외국인 선물</span>
          </nav>

          {/* Page Title */}
          <div className="text-center mb-14">
            <h1 className="font-serif text-3xl lg:text-4xl text-foreground mb-4">
              외국인 선물
            </h1>
            <p className="text-[15px] text-muted-foreground">
              한국을 담아서 건네는 기억에 남는 선물!
            </p>
          </div>

          {/* Product Count & Sort */}
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-border/40">
            <p className="text-[13px] text-muted-foreground">
              전체 <span className="text-foreground font-medium">247</span>개
            </p>
            
            {/* Sort Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsSortOpen(!isSortOpen)}
                className="flex items-center gap-2 text-[13px] text-foreground/80 hover:text-foreground transition-colors px-3 py-1.5 border border-border/50 bg-white"
              >
                <span>{selectedSortLabel}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isSortOpen ? "rotate-180" : ""}`} />
              </button>
              
              {isSortOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-10" 
                    onClick={() => setIsSortOpen(false)} 
                  />
                  <div className="absolute right-0 top-full mt-1 bg-white border border-border/50 shadow-[0_4px_12px_rgba(0,0,0,0.08)] z-20 min-w-[140px]">
                    {sortOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => {
                          setSortBy(option.value)
                          setIsSortOpen(false)
                        }}
                        className={`w-full text-left px-4 py-2.5 text-[13px] transition-colors ${
                          sortBy === option.value 
                            ? "bg-secondary/50 text-foreground" 
                            : "text-foreground/70 hover:bg-secondary/30 hover:text-foreground"
                        }`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 lg:gap-6">
            {products.map((product) => (
              <article
                key={product.id}
                className="group relative"
              >
                <Link href={`/product/${product.id}`} className="block">
                  <div className="relative aspect-square overflow-hidden bg-secondary/30 mb-4 transition-all duration-300 group-hover:shadow-[0_8px_24px_rgba(0,0,0,0.1)] group-hover:scale-[1.02]">
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                      sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
                    />
                    
                    {/* Badges */}
                    {product.badges.length > 0 && (
                      <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                        {product.badges.map((badge) => (
                          <span
                            key={badge}
                            className={`px-2 py-0.5 text-[10px] font-medium text-white ${
                              badge === "BEST" 
                                ? "bg-[#7c6aa5]" 
                                : "bg-[#5a9e8f]"
                            }`}
                          >
                            {badge}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </Link>
                
                {/* Wishlist Button */}
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center bg-white/90 hover:bg-white transition-colors z-10"
                  aria-label="위시리스트에 추가"
                >
                  <Heart 
                    className={`w-4 h-4 transition-colors ${
                      wishlist.includes(product.id) 
                        ? "fill-[#c4a77d] text-[#c4a77d]" 
                        : "text-foreground/50"
                    }`} 
                    strokeWidth={1.5}
                  />
                </button>
                
                {/* Product Info */}
                <div className="space-y-1.5">
                  <p className="text-[10px] tracking-wide text-muted-foreground uppercase">
                    {product.category}
                  </p>
                  
                  <Link href={`/product/${product.productId}`}>
                    <h3 className="text-[13px] text-foreground leading-snug group-hover:text-accent transition-colors line-clamp-2">
                      {product.name}
                    </h3>
                  </Link>
                  
                  <p className="text-[15px] font-semibold text-foreground pt-1">
                    {product.price ? `${product.price.toLocaleString()}원` : "가격 미정"}
                  </p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  )
}
