"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Home, ChevronRight, Heart, ChevronDown } from "lucide-react"
import { Header } from "@/components/museum/header"
import { Footer } from "@/components/museum/footer"

const products = [
  {
    id: 1,
    productId: "foreigner-1",
    category: "외국인 선물",
    name: "호건 에어팟 프로 케이스",
    price: 30000,
    badges: ["MD추천"],
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%201-3DNdrp8w4pRzcRLnClqU2rgm5B8I1d.png",
    filterCategory: "기타",
  },
  {
    id: 2,
    productId: "foreigner-2",
    category: "외국인 선물",
    name: "이순신 전립 와인마개",
    price: 25000,
    badges: ["BEST", "MD추천"],
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%202-JrM4ZXAOI3ZPEs0XbaRg0FhbENitI6.png",
    filterCategory: "기타",
  },
  {
    id: 3,
    productId: "foreigner-3",
    category: "외국인 선물",
    name: "나전 핸드워시 핸드크림 세트(단독 구매)",
    price: 45000,
    badges: ["BEST", "MD추천"],
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%203-hQVmwBUbwRL3mH7hOsmqS9CgsT4OaV.png",
    filterCategory: "전통문양 굿즈",
  },
  {
    id: 4,
    productId: "foreigner-4",
    category: "외국인 선물",
    name: "일월오봉도 앞치마(단독 구매)",
    price: 35000,
    badges: [],
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%204-SNj4ZKgjQpokXu4uBNdPZIfz1TidoL.png",
    filterCategory: "민화 굿즈",
  },
  {
    id: 5,
    productId: "foreigner-5",
    category: "외국인 선물",
    name: "반가사유상 캐릭터 인형(78호)",
    price: 32000,
    badges: ["BEST", "MD추천"],
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%205-8UvXRrZl7v40zCsMaM4CxF8ZvEpmD3.png",
    filterCategory: "캐릭터 굿즈",
  },
  {
    id: 6,
    productId: "foreigner-6",
    category: "외국인 선물",
    name: "등롱 이순신 램프",
    price: 48000,
    badges: [],
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%206-Qr2hL7AcmCVD6hg4uoZJgiKUKiF9fr.png",
    filterCategory: "기타",
  },
  {
    id: 7,
    productId: "foreigner-7",
    category: "외국인 선물",
    name: "나전 호랑이 손거울",
    price: 22000,
    badges: [],
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%207-2MBwd0g0SqfZI7Txa1bqcTvAuERZBz.png",
    filterCategory: "기타",
  },
  {
    id: 8,
    productId: "foreigner-8",
    category: "외국인 선물",
    name: "백은배화접도 3단 자동우산_분홍색",
    price: 28000,
    badges: ["BEST"],
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%208-OiaKcczOXuA5DpnZlWfAQ4MPPHU0Oq.png",
    filterCategory: "민화 굿즈",
  },
]

const filterTabs = [
  { id: "전체", label: "전체" },
  { id: "한글 굿즈", label: "한글 굿즈" },
  { id: "전통문양 굿즈", label: "전통문양 굿즈" },
  { id: "민화 굿즈", label: "민화 굿즈" },
  { id: "캐릭터 굿즈", label: "캐릭터 굿즈" },
]

const sortOptions = [
  { value: "", label: "선택" },
  { value: "popular", label: "인기순" },
  { value: "newest", label: "최신순" },
  { value: "price-low", label: "낮은 가격순" },
  { value: "price-high", label: "높은 가격순" },
]

export default function ForeignerThemePage() {
  const [wishlist, setWishlist] = useState<number[]>([])
  const [sortBy, setSortBy] = useState("")
  const [isSortOpen, setIsSortOpen] = useState(false)
  const [activeFilter, setActiveFilter] = useState("전체")

  const filteredProducts = activeFilter === "전체" 
    ? products 
    : products.filter(product => product.filterCategory === activeFilter)

  const toggleWishlist = (id: number) => {
    setWishlist(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  const selectedSortLabel = sortOptions.find(opt => opt.value === sortBy)?.label || "선택"

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-6 pb-20">
        <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-1.5 text-[12px] text-muted-foreground mb-12">
            <Link href="/" className="hover:text-foreground transition-colors">
              <Home className="w-3.5 h-3.5" />
            </Link>
            <ChevronRight className="w-3 h-3" />
            <Link href="/theme" className="hover:text-foreground transition-colors">
              테마(굿즈픽)
            </Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground">외국인 선물</span>
          </nav>

          {/* Page Title */}
          <div className="text-center mb-10">
            <h1 className="font-serif text-3xl lg:text-4xl text-foreground mb-4">
              외국인 선물
            </h1>
            <p className="text-[15px] text-muted-foreground">
              한국을 담아서 건네는 기억에 남는 선물!
            </p>
          </div>

          {/* Category Filter Tabs */}
          <div className="mb-10 -mx-6 px-6 lg:mx-0 lg:px-0 overflow-x-auto scrollbar-hide">
            <div className="flex gap-2 lg:gap-3 lg:justify-center min-w-max pb-2">
              {filterTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveFilter(tab.id)}
                  className={`px-5 py-2.5 text-[13px] font-medium whitespace-nowrap transition-all duration-200 ${
                    activeFilter === tab.id
                      ? "bg-foreground text-white"
                      : "bg-white text-foreground/70 border border-border/60 hover:border-foreground/30 hover:text-foreground"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Product Count & Sort */}
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-border/40">
            <p className="text-[13px] text-muted-foreground">
              전체 <span className="text-foreground font-medium">{filteredProducts.length}</span>개
            </p>
            
            {/* Sort Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsSortOpen(!isSortOpen)}
                className="flex items-center gap-2 text-[13px] text-foreground/80 hover:text-foreground transition-colors px-3 py-1.5 border border-border/50 bg-white"
              >
                <span>{selectedSortLabel}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isSortOpen ? "rotate-180" : ""}`} />
              </button>
              
              {isSortOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-10" 
                    onClick={() => setIsSortOpen(false)} 
                  />
                  <div className="absolute right-0 top-full mt-1 bg-white border border-border/50 shadow-[0_4px_12px_rgba(0,0,0,0.08)] z-20 min-w-[140px]">
                    {sortOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => {
                          setSortBy(option.value)
                          setIsSortOpen(false)
                        }}
                        className={`w-full text-left px-4 py-2.5 text-[13px] transition-colors ${
                          sortBy === option.value 
                            ? "bg-secondary/50 text-foreground" 
                            : "text-foreground/70 hover:bg-secondary/30 hover:text-foreground"
                        }`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Product Grid or Empty State */}
          {filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20">
              <p className="text-[15px] text-muted-foreground/60">
                상품을 준비 중입니다.
              </p>
            </div>
          ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 lg:gap-6">
            {filteredProducts.map((product) => (
              <article
                key={product.id}
                className="group relative"
              >
                <Link href={`/product/${product.productId}`} className="block">
                  <div className="relative aspect-square overflow-hidden bg-secondary/30 mb-4 transition-all duration-300 group-hover:shadow-[0_8px_24px_rgba(0,0,0,0.1)] group-hover:scale-[1.02]">
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                      sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
                    />
                    
                    {/* Badges */}
                    {product.badges.length > 0 && (
                      <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                        {product.badges.map((badge) => (
                          <span
                            key={badge}
                            className={`px-2 py-0.5 text-[10px] font-medium text-white ${
                              badge === "BEST" 
                                ? "bg-[#7c6aa5]" 
                                : "bg-[#5a9e8f]"
                            }`}
                          >
                            {badge}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </Link>
                
                {/* Wishlist Button */}
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center bg-white/90 hover:bg-white transition-colors z-10"
                  aria-label="위시리스트에 추가"
                >
                  <Heart 
                    className={`w-4 h-4 transition-colors ${
                      wishlist.includes(product.id) 
                        ? "fill-[#c4a77d] text-[#c4a77d]" 
                        : "text-foreground/50"
                    }`} 
                    strokeWidth={1.5}
                  />
                </button>
                
                {/* Product Info */}
                <div className="space-y-1.5">
                  <p className="text-[10px] tracking-wide text-muted-foreground uppercase">
                    {product.category}
                  </p>
                  
                  <Link href={`/product/${product.productId}`}>
                    <h3 className="text-[13px] text-foreground leading-snug group-hover:text-accent transition-colors line-clamp-2">
                      {product.name}
                    </h3>
                  </Link>
                  
                  <p className="text-[15px] font-semibold text-foreground pt-1">
                    {product.price ? `${product.price.toLocaleString()}원` : "가격 미정"}
                  </p>
                </div>
              </article>
            ))}
          </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  )
}
