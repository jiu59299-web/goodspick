"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Home, ChevronRight, Heart, ChevronDown } from "lucide-react"
import { Header } from "@/components/museum/header"
import { Footer } from "@/components/museum/footer"

const products = [
  { id: 1, productId: "collab-1", category: "콜라보", brand: "뮷즈 × 아모레퍼시픽", name: "나전 핸드워시 핸드크림 세트 (단독 구매)", price: 45000, badges: ["BEST", "MD추천"], image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2033-yb9vAEIpppNY0xvUyeBlWcOr83DeeK.png", filterCategory: "K-뷰티 x 전통" },
  { id: 2, productId: "collab-2", category: "콜라보", brand: "뮷즈 × 오이뮤(OIMU)", name: "이순신 전시 자수 책갈피", price: 15000, badges: ["MD추천"], image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2034-kOVuZvevFXB9opBuPZxoXV3SkuS2ga.png", filterCategory: "아트&문구 x 전통" },
  { id: 3, productId: "collab-3", category: "콜라보", brand: "뮷즈 × 오이뮤(OIMU)", name: "이순신 전시 플리츠 가방(중형)", price: 68000, badges: ["BEST", "MD추천"], image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2035-yqZXSOHzjX2UWvFquFFCDLfnvg4Duw.png", filterCategory: "패션 x 전통" },
  { id: 4, productId: "collab-4", category: "콜라보", brand: "뮷즈 × 아모레퍼시픽", name: "도원행주도 핸드크림 립밤 세트 (단독 구매)", price: 33000, badges: ["MD추천"], image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2036-lJA7HKdCfaYLoPPFDSEBXj8Wr6GXb3.png", filterCategory: "K-뷰티 x 전통" },
  { id: 5, productId: "collab-5", category: "콜라보", brand: "뮷즈 × 최고심", name: "반가사유상 리무버블 스티커", price: 5000, badges: ["BEST", "MD추천"], image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2037-vTE070ZkRrPiYmUkgX1WAKQmIqZzku.png", filterCategory: "캐릭터 x 전통" },
  { id: 6, productId: "collab-6", category: "콜라보", brand: "뮷즈 × 최고심", name: "반가사유상 미니어처 마음시리즈 K볼하트 (단독 구매)", price: 45000, badges: ["BEST", "MD추천"], image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2038-WbNuVoo1Dm4M0H2B2OeSNweXVc4fYy.png", filterCategory: "캐릭터 x 전통" },
  { id: 7, productId: "collab-7", category: "콜라보", brand: "뮷즈 × 최고심", name: "반가사유상 안전키링", price: 12000, badges: ["MD추천"], image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2039-Dp3romEPkEXpvtEsE585RJHNJ1f2Hv.png", filterCategory: "캐릭터 x 전통" },
  { id: 8, productId: "collab-8", category: "콜라보", brand: "뮷즈 × 나난", name: "롱롱타임플라워 초충도 에디션2", price: 58000, badges: ["BEST", "MD추천"], image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2040-ZEhARj0ecSVd4TDfTlAJ4tToG7PcTN.png", filterCategory: "아트 오브제 x 전통" },
]

const filterTabs = [
  { id: "전체", label: "전체" },
  { id: "K-뷰티 x 전통", label: "K-뷰티 x 전통" },
  { id: "패션 x 전통", label: "패션 x 전통" },
  { id: "아트&문구 x 전통", label: "아트&문구 x 전통" },
  { id: "캐릭터 x 전통", label: "캐릭터 x 전통" },
  { id: "아트 오브제 x 전통", label: "아트 오브제 x 전통" },
]

const sortOptions = [
  { value: "", label: "선택" },
  { value: "popular", label: "인기순" },
  { value: "newest", label: "최신순" },
  { value: "price-low", label: "낮은 가격순" },
  { value: "price-high", label: "높은 가격순" },
]

export default function CollabThemePage() {
  const [wishlist, setWishlist] = useState<number[]>([])
  const [sortBy, setSortBy] = useState("")
  const [isSortOpen, setIsSortOpen] = useState(false)
  const [activeFilter, setActiveFilter] = useState("전체")

  const filteredProducts = activeFilter === "전체" 
    ? products 
    : products.filter(product => product.filterCategory === activeFilter)

  const toggleWishlist = (id: number) => {
    setWishlist(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  const selectedSortLabel = sortOptions.find(opt => opt.value === sortBy)?.label || "선택"

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-6 pb-20">
        <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-1.5 text-[12px] text-muted-foreground mb-12">
            <Link href="/" className="hover:text-foreground transition-colors">
              <Home className="w-3.5 h-3.5" />
            </Link>
            <ChevronRight className="w-3 h-3" />
            <Link href="/theme" className="hover:text-foreground transition-colors">
              테마(굿즈픽)
            </Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground">콜라보</span>
          </nav>

          {/* Page Title */}
          <div className="text-center mb-10">
            <h1 className="font-serif text-3xl lg:text-4xl text-foreground mb-4">
              콜라보
            </h1>
            <p className="text-[15px] text-muted-foreground">
              전통과 현대가 만나 선사하는 새로운 감각, 뮷즈만이 선보이는 특별한 만남
            </p>
          </div>

          {/* Category Filter Tabs */}
          <div className="mb-10 -mx-6 px-6 lg:mx-0 lg:px-0 overflow-x-auto scrollbar-hide">
            <div className="flex gap-2 lg:gap-3 lg:justify-center min-w-max pb-2">
              {filterTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveFilter(tab.id)}
                  className={`px-5 py-2.5 text-[13px] font-medium whitespace-nowrap transition-all duration-200 ${
                    activeFilter === tab.id
                      ? "bg-foreground text-white"
                      : "bg-white text-foreground/70 border border-border/60 hover:border-foreground/30 hover:text-foreground"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Product Count & Sort */}
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-border/40">
            <p className="text-[13px] text-muted-foreground">
              전체 <span className="text-foreground font-medium">{filteredProducts.length}</span>개
            </p>
            
            {/* Sort Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsSortOpen(!isSortOpen)}
                className="flex items-center gap-2 text-[13px] text-foreground/80 hover:text-foreground transition-colors px-3 py-1.5 border border-border/50 bg-white"
              >
                <span>{selectedSortLabel}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isSortOpen ? "rotate-180" : ""}`} />
              </button>
              
              {isSortOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-10" 
                    onClick={() => setIsSortOpen(false)} 
                  />
                  <div className="absolute right-0 top-full mt-1 bg-white border border-border/50 shadow-[0_4px_12px_rgba(0,0,0,0.08)] z-20 min-w-[140px]">
                    {sortOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => {
                          setSortBy(option.value)
                          setIsSortOpen(false)
                        }}
                        className={`w-full text-left px-4 py-2.5 text-[13px] transition-colors ${
                          sortBy === option.value 
                            ? "bg-secondary/50 text-foreground" 
                            : "text-foreground/70 hover:bg-secondary/30 hover:text-foreground"
                        }`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Product Grid or Empty State */}
          {filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20">
              <p className="text-[15px] text-muted-foreground/60">
                상품을 준비 중입니다.
              </p>
            </div>
          ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 lg:gap-6">
            {filteredProducts.map((product) => (
              <article
                key={product.id}
                className="group relative"
              >
                <Link href={`/product/${product.productId}`} className="block">
                  <div className="relative aspect-square overflow-hidden bg-secondary/30 mb-4 transition-all duration-300 group-hover:shadow-[0_8px_24px_rgba(0,0,0,0.1)] group-hover:scale-[1.02]">
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                      sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
                    />
                    
                    {/* Badges */}
                    <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                      {product.badges.map((badge) => (
                        <span
                          key={badge}
                          className={`px-2 py-0.5 text-[10px] font-medium text-white ${
                            badge === "BEST" 
                              ? "bg-[#7c6aa5]" 
                              : "bg-[#5a9e8f]"
                          }`}
                        >
                          {badge}
                        </span>
                      ))}
                    </div>
                  </div>
                </Link>
                
                {/* Wishlist Button */}
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center bg-white/90 hover:bg-white transition-colors z-10"
                  aria-label="위시리스트에 추가"
                >
                  <Heart 
                    className={`w-4 h-4 transition-colors ${
                      wishlist.includes(product.id) 
                        ? "fill-[#c4a77d] text-[#c4a77d]" 
                        : "text-foreground/50"
                    }`} 
                    strokeWidth={1.5}
                  />
                </button>
                
                {/* Product Info */}
                <div className="space-y-1.5">
                  <p className="text-[10px] tracking-wide text-muted-foreground uppercase">
                    {product.category}
                  </p>
                  
                  {product.brand && (
                    <p className="text-[11px] text-accent font-medium">
                      {product.brand}
                    </p>
                  )}
                  
                  <Link href={`/product/${product.productId}`}>
                    <h3 className="text-[13px] text-foreground leading-snug group-hover:text-accent transition-colors line-clamp-2">
                      {product.name}
                    </h3>
                  </Link>
                  
                  <p className="text-[15px] font-semibold text-foreground pt-1">
                    {product.price ? `${product.price.toLocaleString()}원` : "가격 미정"}
                  </p>
                </div>
              </article>
            ))}
          </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  )
}
