import { Header } from "@/components/museum/header"
import { Hero } from "@/components/museum/hero"
import { ProductGrid } from "@/components/museum/product-grid"
import { CuratorThemes } from "@/components/museum/curator-themes"
import { Categories } from "@/components/museum/categories"
import { Exhibition } from "@/components/museum/exhibition"
import { Story } from "@/components/museum/story"
import { Newsletter } from "@/components/museum/newsletter"
import { Footer } from "@/components/museum/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <ProductGrid />
      <CuratorThemes />
      <Story />
      <Categories />
      <Exhibition />
      <Newsletter />
      <Footer />
    </main>
  )
}
