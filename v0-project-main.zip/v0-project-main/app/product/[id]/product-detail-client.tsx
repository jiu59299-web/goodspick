"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart, Star, Share2, ChevronDown, Minus, Plus } from "lucide-react"
import { Header } from "@/components/museum/header"
import { Footer } from "@/components/museum/footer"

type Product = {
  id: string
  name: string
  brand?: string
  price: number
  rating: number
  reviewCount: number
  badges: string[]
  images: string[]
  breadcrumb: string[]
  specs: Record<string, string>
  options: { label: string; placeholder: string; choices: string[] }[]
  description: string
  artifactDescription?: string
}

export function ProductDetailClient({ product }: { product: Product }) {
  const [selectedImage, setSelectedImage] = useState(0)
  const [wishlist, setWishlist] = useState(false)
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({})
  const [quantity, setQuantity] = useState(1)
  const [openDropdown, setOpenDropdown] = useState<string | null>(null)
  const [isArtifactInfoOpen, setIsArtifactInfoOpen] = useState(false)

  const toggleWishlist = () => setWishlist(!wishlist)

  const handleOptionSelect = (optionLabel: string, choice: string) => {
    setSelectedOptions(prev => ({ ...prev, [optionLabel]: choice }))
    setOpenDropdown(null)
  }

  const calculateTotal = () => {
    const basePrice = product.price ?? 0
    let total = basePrice * quantity
    const bagOption = selectedOptions["뮷즈가방"]
    if (bagOption?.includes("S")) total += 3000 * quantity
    if (bagOption?.includes("M")) total += 5000 * quantity
    if (!selectedOptions["선택옵션"]) return 0
    return total
  }

  const getBadgeStyle = (badge: string) => {
    switch (badge) {
      case "NEW": return "bg-[#4a9f4a] text-white"
      case "BEST": return "bg-[#7c6aa5] text-white"
      case "MD추천": return "bg-[#5bb5b5] text-white"
      default: return "bg-muted text-foreground"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="max-w-7xl mx-auto px-4 lg:px-8 py-6">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-[13px] text-muted-foreground mb-6">
          <Link href="/" className="hover:text-foreground transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
          </Link>
          {product.breadcrumb.map((crumb, index) => (
            <span key={index} className="flex items-center gap-2">
              <span className="text-muted-foreground/50">&gt;</span>
              <Link href="#" className="hover:text-foreground transition-colors">{crumb}</Link>
            </span>
          ))}
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Left: Product Images */}
          <div className="space-y-4">
            <div className="aspect-square bg-[#f5f5f5] relative overflow-hidden">
              <Image
                src={product.images[selectedImage]}
                alt={product.name}
                fill
                className="object-cover"
                priority
                unoptimized
              />
            </div>
            <div className="flex gap-2">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`w-20 h-20 relative overflow-hidden border-2 transition-colors ${
                    selectedImage === index
                      ? "border-foreground"
                      : "border-transparent hover:border-muted-foreground/30"
                  }`}
                >
                  <Image
                    src={image}
                    alt={`${product.name} ${index + 1}`}
                    fill
                    className="object-cover"
                    unoptimized
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Right: Product Info */}
          <div className="space-y-5">
            {/* Badges */}
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                {product.badges.map((badge) => (
                  <span key={badge} className={`px-4 py-1.5 text-[13px] font-medium rounded-sm ${getBadgeStyle(badge)}`}>
                    {badge}
                  </span>
                ))}
              </div>
              <button className="p-2 hover:bg-secondary/50 transition-colors rounded-full" aria-label="공유하기">
                <Share2 className="w-5 h-5 text-muted-foreground" />
              </button>
            </div>

            {/* Product Name */}
            <div>
              <h1 className="text-xl lg:text-2xl font-medium text-foreground leading-tight">
                {product.name}
              </h1>
              {product.brand && (
                <p className="text-[15px] text-muted-foreground mt-1">{product.brand}</p>
              )}
            </div>

            {/* Price */}
            <p className="text-[28px] font-bold text-foreground">
              {product.price.toLocaleString()}
            </p>

            {/* Rating & Reviews */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-0.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-4 h-4 ${
                      star <= Math.floor(product.rating)
                        ? "fill-[#7c6aa5] text-[#7c6aa5]"
                        : star <= product.rating
                        ? "fill-[#7c6aa5]/50 text-[#7c6aa5]"
                        : "fill-muted text-muted"
                    }`}
                  />
                ))}
              </div>
              <span className="text-[14px] font-medium text-foreground">{product.rating}</span>
              <Link href="#reviews" className="text-[13px] text-muted-foreground hover:text-foreground transition-colors">
                리뷰 {product.reviewCount}개
              </Link>
            </div>

            {/* Product Specs Table */}
            <div className="border-t border-border/40">
              {Object.entries(product.specs).map(([label, value]) => {
                if (label === "기타") {
                  const artifactText = product.artifactDescription || value
                  return (
                    <div key={label} className="border-b border-border/30">
                      <button
                        onClick={() => setIsArtifactInfoOpen(!isArtifactInfoOpen)}
                        className="w-full flex items-center py-3 text-left"
                      >
                        <span className="w-28 flex-shrink-0 text-[13px] font-medium text-foreground/80">
                          유물·상품 설명
                        </span>
                        <div className="flex items-center gap-1.5 text-[13px] text-[#7c6aa5] font-medium">
                          <span>{isArtifactInfoOpen ? "접기" : "자세히 보기"}</span>
                          <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${isArtifactInfoOpen ? "rotate-180" : ""}`} />
                        </div>
                      </button>
                      <div className={`overflow-hidden transition-all duration-300 ease-out ${isArtifactInfoOpen ? "max-h-[800px] opacity-100 pb-4" : "max-h-0 opacity-0"}`}>
                        <div className="pl-28 pr-4">
                          <p className="text-[13px] text-[#555] leading-[1.8]">
                            {(() => {
                              const linkMap: Record<string, string> = {
                                '호건': 'https://www.kculture.or.kr/brd/board/1077/L/menu/1067?brdType=R&bbIdx=343',
                                '수군조련도 병풍': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=9165',
                                '나전칠십장생문빗접': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=133538',
                                '일월오봉도': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=183954',
                                '금동 반가사유상': 'https://www.emuseum.go.kr/detail?relicId=PS0100100100500331200000',
                                '나전 장식 베갯모': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=35847513',
                                '십장생도': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=36553219',
                                '단호흉배': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=107825',
                                '단호 흉배': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=107825',
                                '얼굴무늬 수막새': 'https://gyeongju.museum.go.kr/kor/html/sub04/0401.html?mode=V&id=PS0100100200100156400000&cate_code=&cate_gubun=',
                                '토우 장식 항아리': 'https://gyeongju.museum.go.kr/kor/html/sub04/0402.html?mode=V&dvs_code=&mng_no=42&GotoPage=2',
                                '분청사기 철화 연꽃 물고기 무늬 병': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=1429',
                                '경주 백률사 금동약사여래입상': 'https://www.heritage.go.kr/heri/cul/culSelectDetail.do;jsessionid=hi5wZixpE0ls6UHPePElB27VucehuA4ofeHSIsIiMtE52x73lxWaKzoPaiDOU0ge.cpawas_servlet_engine1?culPageNo=1&region=&searchCondition=&searchCondition2=&s_kdcd=&s_ctcd=37&ccbaKdcd=11&ccbaAsno=0000280000000&ccbaCtcd=37&ccbaCpno=1113700280000&ccbaCndt=&ccbaLcto=12&stCcbaAsno=&endCcbaAsno=&stCcbaAsdt=&endCcbaAsdt=&ccbaPcd1=&chGubun=&header=region&returnUrl=%2Fheri%2Fcul%2FculSelectRegionList.do&pageNo=2_2_1_0&sngl=Y',
                                '금제 관 꾸미개': 'https://www.emuseum.go.kr/detail?relicId=PS0100100400700004400000',
                                '청자 버드나무 학 동자무늬 매병': 'https://www.emuseum.go.kr/detail?relicId=PS0100100100900135100000',
                                '호작도': 'https://www.emuseum.go.kr/detail?relicId=PS0100100100900261300000',
                                '길상의 그림': 'https://www.emuseum.go.kr/detail?relicId=PS0100100100500100300000',
                                '책가도': 'https://www.emuseum.go.kr/detail?relicId=PS0100100101600233200000',
                                '데니 태극기': 'https://www.emuseum.go.kr/detail?relicId=PS0100100101100626600000',
                                '인왕제색도': 'https://www.emuseum.go.kr/detail?relicId=PS0100100102400000100000',
                                '경주 불국사 다보탑': 'https://www.emuseum.go.kr/detail?relicId=PS0100100102002957700000',
                                // 오픈런 테마
                                '두정갑': 'https://lrl.kr/YeZj',
                                '까치 호랑이': 'https://lrl.kr/cj9TY',
                                '풍속화': 'https://lrl.kr/fHXbC',
                                '나전칠기': 'https://lrl.kr/dF4OI',
                                '청자 상감 운학문 매병': 'https://lrl.kr/cj9T6',
                                '석굴암': 'https://lrl.kr/fHXbL',
                                '대형 향로': 'https://lrl.kr/bEcrN',
                                // 콜라보 테마
                                '나전빗접': 'https://buly.kr/CslbKFl',
                                '장방패': 'https://buly.kr/8enPmtT',
                                '몽유도원도': 'https://buly.kr/90cvkl4',
                                '금동미륵보살반가사유상': 'https://buly.kr/1n5rXS2',
                                '반가사유상': 'https://buly.kr/1n5rXS2',
                                '��충도': 'https://buly.kr/8Ixtq1v',
                                '수군조련도': 'https://buly.kr/6MtZ2T2',
                                // FLEX 테마
                                '나전 팔각 관모함': 'https://www.emuseum.go.kr/detail?relicId=PS0100200100107251600000',
                                '청자 상감 구름 학무늬 매병': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=1126',
                                '향원익청': 'https://kansong.org/foundation/index.do?menu_id=00004389&menu_link=%2Ffront%2Fclctn%2FdetailCollectionFront.do&clctn_id=CLCTN_00000159&clctn_dcd=ART_00025_02&searchCondition6=&pageUnitF=12&searchKeyword=%ED%96%A5%EC%9B%90%EC%9D%B5%EC%B2%AD',
                                '꽃과 나비': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=980',
                                '천마총금관': 'https://www.emuseum.go.kr/detail?relicId=PS0100100200100227400000',
                                '조선태조어진': 'https://www.heritage.go.kr/heri/cul/culSelectDetail.do?VdkVgwKey=11,03170000,35&pageNo=1_1_1_0',
                                '국보 금관총 금관 및 금제 관식': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=159727',
                                // 집꾸 테마
                                '나전함': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=36556459',
                                '숭렬전': 'https://www.culture.go.kr/portal/cltKnw/usePtt/viewOrigin.do?menuNo=200059&did=59463',
                                '귀진사 극락전 액방 단청문양': 'https://www.emuseum.go.kr/detail?relicId=PS0100200100105696000000',
                                '청자 상감 국화무늬 잔과 잔받침': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=2309',
                                '백자이부잔': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=36551640',
                                '백자 청화 국화 구름무늬 접시': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=8843',
                                '백자 청화 괴석 꽃 무늬 편병': 'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?schM=view&searchId=search&relicId=16691',
                              }
                              const pattern = new RegExp(`(${Object.keys(linkMap).join('|')})`, 'g')
                              const parts = artifactText.split(pattern)
                              return parts.map((part, idx) => {
                                if (linkMap[part]) {
                                  return (
                                    <a
                                      key={idx}
                                      href={linkMap[part]}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="inline-flex items-center text-[#7c6aa5] font-medium underline underline-offset-2 decoration-[#7c6aa5]/40 hover:text-[#5a4a7a] hover:decoration-[#5a4a7a] cursor-pointer transition-all duration-200"
                                    >
                                      {part}
                                      <svg className="w-3 h-3 ml-0.5 inline-block" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3.5 2.5H9.5V8.5M9.5 2.5L2.5 9.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                                      </svg>
                                    </a>
                                  )
                                }
                                return <span key={idx}>{part}</span>
                              })
                            })()}
                          </p>
                        </div>
                      </div>
                    </div>
                  )
                }

                return (
                  <div key={label} className="flex py-3 border-b border-border/30">
                    <span className="w-28 flex-shrink-0 text-[13px] font-medium text-foreground/80">{label}</span>
                    <span className="text-[13px] text-[#7c6aa5] leading-relaxed whitespace-pre-line">{value}</span>
                  </div>
                )
              })}
            </div>

            {/* Option Selectors */}
            <div className="space-y-2 pt-2">
              {product.options.map((option) => (
                <div key={option.label} className="relative">
                  <button
                    onClick={() => setOpenDropdown(openDropdown === option.label ? null : option.label)}
                    className="w-full flex items-center justify-between px-4 py-3 border border-border/60 text-[13px] text-left hover:border-foreground/30 transition-colors"
                  >
                    <span className={selectedOptions[option.label] ? "text-foreground" : "text-muted-foreground"}>
                      {selectedOptions[option.label] || option.placeholder}
                    </span>
                    <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${openDropdown === option.label ? "rotate-180" : ""}`} />
                  </button>
                  {openDropdown === option.label && (
                    <div className="absolute top-full left-0 right-0 z-10 bg-background border border-border/60 border-t-0 shadow-lg">
                      {option.choices.map((choice) => (
                        <button
                          key={choice}
                          onClick={() => handleOptionSelect(option.label, choice)}
                          className="w-full px-4 py-3 text-[13px] text-left hover:bg-secondary/50 transition-colors border-b border-border/20 last:border-b-0"
                        >
                          {choice}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Selected Option Display */}
            {selectedOptions["선��옵션"] && (
              <div className="bg-[#f8f8f8] p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[13px] text-foreground">{selectedOptions["선택옵션"]}</span>
                  <button
                    onClick={() => {
                      const newOptions = { ...selectedOptions }
                      delete newOptions["선택옵션"]
                      setSelectedOptions(newOptions)
                      setQuantity(1)
                    }}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center border border-border/60">
                    <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="p-2 hover:bg-secondary/50 transition-colors">
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="px-4 text-[14px] font-medium">{quantity}</span>
                    <button onClick={() => setQuantity(quantity + 1)} className="p-2 hover:bg-secondary/50 transition-colors">
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <span className="text-[15px] font-medium">{(product.price * quantity).toLocaleString()}원</span>
                </div>
              </div>
            )}

            {/* Total Price */}
            <div className="flex items-center justify-between pt-2">
              <span className="text-[14px] text-foreground">주문금액</span>
              <span className="text-xl font-bold text-foreground">{calculateTotal().toLocaleString()}원</span>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-2">
              <button
                onClick={toggleWishlist}
                className={`flex items-center justify-center w-14 h-12 border transition-colors ${
                  wishlist ? "border-[#7c6aa5] bg-[#7c6aa5]/5" : "border-border/60 hover:border-foreground/30"
                }`}
                aria-label="찜하기"
              >
                <Heart className={`w-5 h-5 ${wishlist ? "fill-[#7c6aa5] text-[#7c6aa5]" : "text-muted-foreground"}`} />
              </button>
              <button className="flex-1 h-12 border border-foreground text-foreground text-[14px] font-medium hover:bg-secondary/50 transition-colors">
                장바구니
              </button>
              <button className="flex-1 h-12 bg-foreground text-background text-[14px] font-medium hover:bg-foreground/90 transition-colors">
                바로구매
              </button>
            </div>
          </div>
        </div>

        {/* Product Description Section */}
        <section className="mt-16 pt-8 border-t border-border/40">
          <h2 className="text-lg font-medium text-foreground mb-6">상품 설명</h2>
          <p className="text-[14px] text-muted-foreground leading-relaxed">{product.description}</p>
        </section>

        {/* Reviews Section */}
        <section id="reviews" className="mt-16 pt-8 border-t border-border/40">
          <h2 className="text-lg font-medium text-foreground mb-6">리뷰 ({product.reviewCount})</h2>
          <p className="text-[14px] text-muted-foreground">리뷰 섹션이 여기에 표시됩니다.</p>
        </section>
      </main>
    </div>
  )
}
