import { productsData } from "@/lib/products-data"
import { ProductDetailClient } from "./product-detail-client"

export default async function ProductDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const product = productsData[id]
  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <p className="text-muted-foreground text-sm">상품을 찾을 수 없습니다.</p>
      </div>
    )
  }
  return <ProductDetailClient product={product} />
}
