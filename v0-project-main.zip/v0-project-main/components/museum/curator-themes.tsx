"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import Link from "next/link"

const themes = [
  {
    id: 1,
    name: "가벼운 선물",
    description: "1-3만원대 인기 선물",
    href: "/theme/light-gift",
    image: "/images/themes/light_gift_no_text.webp",
    bgColor: "from-rose-100 via-pink-50 to-orange-100",
  },
  {
    id: 2,
    name: "외국인 선물",
    description: "한국의 미를 담아서",
    href: "/theme/foreigner",
    image: "/images/themes/v3_foreigner_gift.webp",
    bgColor: "from-sky-100 via-blue-50 to-indigo-100",
  },
  {
    id: 3,
    name: "오픈런",
    description: "놓치면 후회할 아이템",
    href: "/theme/open-run",
    image: "/images/themes/final_v8_open_run.webp",
    bgColor: "from-slate-100 via-stone-50 to-zinc-100",
  },
  {
    id: 4,
    name: "콜라보",
    description: "특별한 협업 컬렉션",
    href: "/theme/collab",
    image: "/images/themes/collab-collaboration.png",
    bgColor: "from-violet-100 via-purple-50 to-fuchsia-100",
  },
  {
    id: 5,
    name: "액운타파",
    description: "행운을 부르는 굿즈",
    href: "/theme/luck",
    image: "/images/themes/warding_off_evil_no_text.webp",
    bgColor: "from-lime-100 via-green-50 to-emerald-100",
  },
  {
    id: 6,
    name: "집꾸",
    description: "공간에 품격을 더하다",
    href: "/theme/home-decor",
    image: "/images/themes/final_v8_home_decor.webp",
    bgColor: "from-amber-100 via-yellow-50 to-orange-100",
  },
  {
    id: 7,
    name: "FLEX",
    description: "국보급 감성의 프리미엄",
    href: "/theme/flex",
    image: "/images/themes/v7_flex.webp",
    bgColor: "from-neutral-100 via-stone-50 to-slate-100",
  },
]

export function CuratorThemes() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.disconnect()
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 lg:py-32">
      <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
        {/* Section Header */}
        <div className={`mb-16 lg:mb-20 ${isVisible ? "animate-fade-up" : "opacity-0"}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-[11px] tracking-[0.15em] text-accent uppercase font-medium">Curator&apos;s Pick</span>
              <span className="w-8 h-[1px] bg-border" />
              <h2 className="text-lg lg:text-xl font-medium text-foreground">
                테마별 컬렉션
              </h2>
            </div>
            <Link
              href="/themes"
              className="text-[12px] tracking-wide text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"
            >
              전체보기
              <span className="w-3 h-3 flex items-center justify-center">›</span>
            </Link>
          </div>
        </div>

        {/* Theme Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-5 gap-y-8">
          {themes.map((theme, index) => (
            <Link
              key={theme.id}
              href={theme.href}
              className={`group flex flex-col gap-4 ${
                isVisible ? "animate-fade-up opacity-0" : "opacity-0"
              }`}
              style={{
                animationDelay: `${0.2 + index * 0.08}s`,
                animationFillMode: "forwards",
              }}
            >
              {/* Image Card */}
              <div
                className={`relative aspect-square rounded-3xl overflow-hidden bg-gradient-to-br ${theme.bgColor} transition-transform duration-300 group-hover:scale-[1.03]`}
              >
                <Image
                  src={theme.image}
                  alt={theme.name}
                  fill
                  className="object-contain object-center p-5 transition-transform duration-500 group-hover:scale-110"
                  sizes="(max-width: 768px) 50vw, (max-width: 1024px) 25vw, 20vw"
                />
              </div>

              {/* Text below card */}
              <div className="text-center px-1">
                <h3 className="font-medium text-[15px] text-foreground">
                  {theme.name}
                </h3>
                <p className="text-[12px] text-muted-foreground mt-1 leading-relaxed">
                  {theme.description}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
