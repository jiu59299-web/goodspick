"use client"

import { useEffect, useRef, useState } from "react"
import { ArrowRight } from "lucide-react"

export function Newsletter() {
  const [isVisible, setIsVisible] = useState(false)
  const [email, setEmail] = useState("")
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.disconnect()
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle newsletter signup
    console.log("[v0] Newsletter signup:", email)
    setEmail("")
  }

  return (
    <section ref={sectionRef} className="py-24 lg:py-32 bg-foreground text-primary-foreground">
      <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          <p
            className={`text-xs tracking-[0.3em] text-primary-foreground/60 mb-4 uppercase ${
              isVisible ? "animate-fade-up" : "opacity-0"
            }`}
            style={{ animationDelay: "0.1s", animationFillMode: "forwards" }}
          >
            Newsletter
          </p>
          <h2
            className={`font-serif text-3xl lg:text-4xl tracking-tight mb-6 ${
              isVisible ? "animate-fade-up" : "opacity-0"
            }`}
            style={{ animationDelay: "0.2s", animationFillMode: "forwards" }}
          >
            뉴스레터 구독하기
          </h2>
          <p
            className={`text-primary-foreground/70 mb-10 ${
              isVisible ? "animate-fade-up" : "opacity-0"
            }`}
            style={{ animationDelay: "0.3s", animationFillMode: "forwards" }}
          >
            신상품 소식, 기획전 안내, 회원 전용 혜택을 가장 먼저 받아보세요.
          </p>

          <form
            onSubmit={handleSubmit}
            className={`flex flex-col sm:flex-row gap-4 max-w-md mx-auto ${
              isVisible ? "animate-fade-up" : "opacity-0"
            }`}
            style={{ animationDelay: "0.4s", animationFillMode: "forwards" }}
          >
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="이메일 주소"
              required
              className="flex-1 px-5 py-3.5 bg-transparent border border-primary-foreground/30 text-primary-foreground placeholder:text-primary-foreground/40 focus:border-primary-foreground focus:outline-none transition-colors text-sm tracking-wide"
            />
            <button
              type="submit"
              className="group inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-primary-foreground text-foreground hover:bg-accent hover:text-foreground transition-colors duration-300 text-sm tracking-wider"
            >
              <span>구독</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" strokeWidth={1.5} />
            </button>
          </form>

          <p
            className={`mt-6 text-xs text-primary-foreground/50 ${
              isVisible ? "animate-fade-up" : "opacity-0"
            }`}
            style={{ animationDelay: "0.5s", animationFillMode: "forwards" }}
          >
            구독 신청 시 개인정보처리방침에 동의하게 됩니다.
          </p>
        </div>
      </div>
    </section>
  )
}
