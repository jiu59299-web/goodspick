"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export function Story() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.disconnect()
        }
      },
      { threshold: 0.15 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 lg:py-32 bg-secondary/30">
      <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <div
            className={`relative ${isVisible ? "animate-fade-up" : "opacity-0"}`}
            style={{ animationDelay: "0.1s", animationFillMode: "forwards" }}
          >
            <div className="relative aspect-[4/5] overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?w=800&q=80"
                alt="뮤지엄 전시 공간"
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 50vw"
              />
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 border border-accent/30 hidden lg:block" />
          </div>

          {/* Content */}
          <div>
            <div
              className={`${isVisible ? "animate-fade-up" : "opacity-0"}`}
              style={{ animationDelay: "0.3s", animationFillMode: "forwards" }}
            >
              <p className="text-xs tracking-[0.3em] text-muted-foreground mb-4 uppercase">
                Our Story
              </p>
              <h2 className="font-serif text-3xl lg:text-4xl xl:text-5xl tracking-tight leading-tight mb-8">
                천년의 유산을<br />
                일상의 가치로
              </h2>
            </div>

            <div
              className={`space-y-6 ${isVisible ? "animate-fade-up" : "opacity-0"}`}
              style={{ animationDelay: "0.5s", animationFillMode: "forwards" }}
            >
              <p className="text-muted-foreground leading-relaxed">
                MU:DS는 국립박물관의 소장품에서 영감받아 탄생한 프리미엄 뮤지엄 굿즈 브랜드입니다. 
                우리는 단순한 기념품을 넘어, 천년의 역사가 담긴 예술품의 아름다움을 현대적 감각으로 재해석합니다.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                장인의 손길로 완성되는 각각의 제품에는 전통의 미학과 현대적 실용성이 조화롭게 담겨 있습니다.
                박물관의 전시실을 떠나 일상 속에서도 예술을 경험할 수 있도록, 우리는 매일 새로운 영감을 찾습니다.
              </p>
            </div>

            <div
              className={`mt-10 ${isVisible ? "animate-fade-up" : "opacity-0"}`}
              style={{ animationDelay: "0.7s", animationFillMode: "forwards" }}
            >
              <Link
                href="/about"
                className="group inline-flex items-center gap-3 text-sm tracking-wider text-foreground hover:text-accent transition-colors duration-300"
              >
                <span>브랜드 스토리</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" strokeWidth={1.5} />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
