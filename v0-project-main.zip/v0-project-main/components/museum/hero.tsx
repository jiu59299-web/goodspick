"use client"

import { useState, useEffect, useCallback } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"

const slides = [
  {
    id: 1,
    subtitle: "국립박물관 유물의 아름다움이 내 일상으로",
    title: "일상에서 만나는\n박물관 유물",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1-ZrV9yltoaM3pCKqI6xbJLkh5Fz4Unu.png",
  },
  {
    id: 2,
    subtitle: "천년의 미학을 담은 프리미엄 컬렉션",
    title: "전통과 현대의\n조화로운 만남",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/33-co5aVyXLiWMKTOOkvVz5OyQ19FgUzg.png",
  },
  {
    id: 3,
    subtitle: "소장품에서 영감받은 특별한 아이템",
    title: "예술을 품은\n일상의 오브제",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/22-0vsd7r6sKevbgewOgBAbxshpFTsdgJ.png",
  },
  {
    id: 4,
    subtitle: "2024 뮤지엄 굿즈 신상품 컬렉션",
    title: "새로운 시선으로\n바라본 유산",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/12121-oGoq3MdXyNp5H4eHYTP4L9UNHFYoWO.png",
  },
]

export function Hero() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)

  const goToSlide = useCallback((index: number) => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentSlide(index)
    setTimeout(() => setIsAnimating(false), 800)
  }, [isAnimating])

  const nextSlide = useCallback(() => {
    goToSlide((currentSlide + 1) % slides.length)
  }, [currentSlide, goToSlide])

  const prevSlide = useCallback(() => {
    goToSlide((currentSlide - 1 + slides.length) % slides.length)
  }, [currentSlide, goToSlide])

  useEffect(() => {
    const timer = setInterval(nextSlide, 6000)
    return () => clearInterval(timer)
  }, [nextSlide])

  return (
    <section className="relative h-[85vh] lg:h-[90vh] overflow-hidden">
      {/* Slides */}
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
          }`}
        >
          {/* Background Image */}
          <div className="absolute inset-0">
            <div
              className={`absolute inset-0 bg-cover bg-center ${
                index === currentSlide ? "animate-slow-zoom" : ""
              }`}
              style={{ backgroundImage: `url(${slide.image})` }}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/70 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-background/50 via-transparent to-transparent" />
          </div>

          {/* Content */}
          <div className="relative h-full flex items-center">
            <div className="mx-auto max-w-[1400px] px-6 lg:px-8 w-full">
              <div className="max-w-xl lg:max-w-2xl">
                <p
                  className={`text-xs lg:text-sm tracking-[0.2em] text-muted-foreground mb-4 lg:mb-6 uppercase ${
                    index === currentSlide ? "animate-fade-up opacity-0" : ""
                  }`}
                  style={{ animationDelay: "0.2s", animationFillMode: "forwards" }}
                >
                  {slide.subtitle}
                </p>
                <h1
                  className={`font-serif text-4xl sm:text-5xl lg:text-7xl leading-[1.15] tracking-tight text-foreground whitespace-pre-line ${
                    index === currentSlide ? "animate-fade-up opacity-0" : ""
                  }`}
                  style={{ animationDelay: "0.4s", animationFillMode: "forwards" }}
                >
                  {slide.title}
                </h1>
                <div
                  className={`mt-8 lg:mt-12 ${
                    index === currentSlide ? "animate-fade-up opacity-0" : ""
                  }`}
                  style={{ animationDelay: "0.6s", animationFillMode: "forwards" }}
                >
                  <button className="group inline-flex items-center gap-3 text-sm tracking-wider text-foreground hover:text-accent transition-colors duration-300">
                    <span>컬렉션 보기</span>
                    <span className="w-8 h-[1px] bg-foreground group-hover:w-12 group-hover:bg-accent transition-all duration-300" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Slide Controls */}
      <div className="absolute bottom-8 lg:bottom-12 left-6 lg:left-8 z-20 flex items-center gap-6">
        <div className="flex items-center gap-4">
          <button
            onClick={prevSlide}
            className="w-10 h-10 flex items-center justify-center border border-foreground/30 hover:border-foreground hover:bg-foreground hover:text-primary-foreground transition-all duration-300"
            aria-label="이전 슬라이드"
          >
            <ChevronLeft className="w-4 h-4" strokeWidth={1.5} />
          </button>
          <button
            onClick={nextSlide}
            className="w-10 h-10 flex items-center justify-center border border-foreground/30 hover:border-foreground hover:bg-foreground hover:text-primary-foreground transition-all duration-300"
            aria-label="다음 슬라이드"
          >
            <ChevronRight className="w-4 h-4" strokeWidth={1.5} />
          </button>
        </div>
        <div className="flex items-center gap-2 text-sm tracking-wider">
          <span className="font-serif text-lg">{String(currentSlide + 1).padStart(2, "0")}</span>
          <span className="w-8 h-[1px] bg-foreground/30" />
          <span className="text-muted-foreground">{String(slides.length).padStart(2, "0")}</span>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 lg:bottom-12 right-6 lg:right-8 z-20 flex gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`h-[2px] transition-all duration-500 ${
              index === currentSlide
                ? "w-8 bg-foreground"
                : "w-4 bg-foreground/30 hover:bg-foreground/50"
            }`}
            aria-label={`슬라이드 ${index + 1}로 이동`}
          />
        ))}
      </div>
    </section>
  )
}
