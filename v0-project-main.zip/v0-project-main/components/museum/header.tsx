"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { Search, Heart, ShoppingBag, Menu, X, ChevronDown } from "lucide-react"

const menuItems = [
  { label: "카테고리", href: "/category", hasCategoryDropdown: true },
  { label: "전체상품", href: "/products" },
  { label: "테마(굿즈픽)", href: "/theme", hasDropdown: true },
  { label: "신상품", href: "/new" },
  { label: "베스트", href: "/best" },
  { label: "기획전·이벤트", href: "/exhibition" },
  { label: "기업특판", href: "/b2b" },
]

// Category Mega Menu Data
const categoryRow1 = [
  {
    id: "stationery",
    title: "문구/사무",
    items: ["노트/수첩/메모", "필기류/필통", "엽서/봉투", "명함집", "자석/책갈피", "스티커/테이프", "기타"],
  },
  {
    id: "fashion",
    title: "패션/생활 용품",
    items: ["손수건/스카프", "가방/지갑/파우치", "의류", "전통부채", "우산/양산", "액세서리", "거울", "배지/키링", "기타"],
  },
  {
    id: "interior",
    title: "인테리어 소품",
    items: ["미니어처", "인센스/방향제/캔들", "무드등/조명", "아트프린트", "쿠션/패브릭", "장식소품", "기타"],
  },
  {
    id: "kitchen",
    title: "주방/식기",
    items: ["컵/텀블러", "접시/그릇", "수저", "쟁반/소반", "코스터", "기타"],
  },
  {
    id: "digital",
    title: "디지털/모바일",
    items: ["모바일 액세서리", "충전기", "스마트톡", "기타"],
  },
]

const categoryRow2 = [
  {
    id: "hobby",
    title: "취미/완구",
    items: ["DIY/만들기", "놀이/장난감", "기타"],
  },
  {
    id: "books",
    title: "도서",
    items: ["상설전시도록", "특별전시도록", "어린이 도서", "기타"],
  },
  {
    id: "crafts",
    title: "공예품",
    items: ["나전", "도자기", "금속", "기타"],
  },
  {
    id: "museum-special",
    title: "박물관특화상품",
    items: ["중앙박물관", "경주박물관", "광주박물관", "대구박물관", "부여박물관", "익산박물관", "전주박물관", "진주박물관"],
  },
  {
    id: "sale",
    title: "세일",
    items: [],
    isSale: true,
  },
]

// Row 1: 4 items
const themeRow1 = [
  {
    id: "light-gift",
    title: "가벼운 선물",
    description: "1-3만원대 인기 선물",
    image: "https://i.ibb.co/DyYXnSF/v10-light-gift.webp",
    href: "/theme/light-gift",
  },
  {
    id: "foreigner",
    title: "외국인 선물",
    description: "한국의 미를 담아서",
    image: "https://i.ibb.co/yBmLXMbv/v3-foreigner-gift.png",
    href: "/theme/foreigner",
  },
  {
    id: "open-run",
    title: "오픈런",
    description: "놓치면 후회할 아이템",
    image: "https://i.ibb.co/Vk69LLb/v10-open-run.webp",
    href: "/theme/open-run",
  },
  {
    id: "collab",
    title: "콜라보",
    description: "특별한 협업 컬렉션",
    image: "https://i.ibb.co/4wMnBFFp/v10-collaboration.webp",
    href: "/theme/collab",
  },
]

// Row 2: 3 items (centered)
const themeRow2 = [
  {
    id: "luck",
    title: "액운타파",
    description: "행운을 부르는 굿즈",
    image: "https://i.ibb.co/1VXq3nL/v10-warding-off-evil.webp",
    href: "/theme/luck",
  },
  {
    id: "home-decor",
    title: "집꾸",
    description: "공간에 품격을 더하다",
    image: "https://i.ibb.co/k2pZhN4g/v10-home-decor.webp",
    href: "/theme/home-decor",
  },
  {
    id: "flex",
    title: "FLEX",
    description: "국보급 감성의 프리미엄",
    image: "https://i.ibb.co/vCSwZpqN/v10-flex.webp",
    href: "/theme/flex",
  },
]

const themeCategories = [...themeRow1, ...themeRow2]

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isThemeDropdownOpen, setIsThemeDropdownOpen] = useState(false)
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState(false)
  const themeDropdownTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const categoryDropdownTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleThemeDropdownEnter = () => {
    if (themeDropdownTimeoutRef.current) {
      clearTimeout(themeDropdownTimeoutRef.current)
    }
    setIsCategoryDropdownOpen(false)
    setIsThemeDropdownOpen(true)
  }

  const handleThemeDropdownLeave = () => {
    themeDropdownTimeoutRef.current = setTimeout(() => {
      setIsThemeDropdownOpen(false)
    }, 150)
  }

  const handleCategoryDropdownEnter = () => {
    if (categoryDropdownTimeoutRef.current) {
      clearTimeout(categoryDropdownTimeoutRef.current)
    }
    setIsThemeDropdownOpen(false)
    setIsCategoryDropdownOpen(true)
  }

  const handleCategoryDropdownLeave = () => {
    categoryDropdownTimeoutRef.current = setTimeout(() => {
      setIsCategoryDropdownOpen(false)
    }, 150)
  }

  return (
    <>
      {/* Top Bar */}
      <div className="hidden lg:block border-b border-border/40 bg-[#faf8f5]">
        <div className="mx-auto max-w-[1400px] px-8">
          <div className="flex justify-between items-center h-8">
            <p className="text-[11px] tracking-wide text-muted-foreground">
              5만원 이상 구매 시 <span className="text-accent font-medium">무료배송</span>
            </p>
            <div className="flex items-center text-[11px] tracking-wide text-muted-foreground">
              <Link href="/notice" className="hover:text-foreground transition-colors">공지사항</Link>
              <span className="mx-2.5 text-border/60">|</span>
              <Link href="/cs" className="hover:text-foreground transition-colors">고객센터</Link>
              <span className="mx-2.5 text-border/60">|</span>
              <Link href="/login" className="hover:text-foreground transition-colors">로그인</Link>
              <span className="mx-2.5 text-border/60">|</span>
              <Link href="/signup" className="hover:text-foreground transition-colors">회원가입</Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header
        className={`sticky top-0 z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-background/95 backdrop-blur-md shadow-[0_1px_0_rgba(0,0,0,0.04)]"
            : "bg-background"
        }`}
      >
        <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
          <div className="flex items-center justify-between h-14 lg:h-[72px]">
            {/* Logo */}
            <Link href="/" className="flex items-center group">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-removebg-preview-i418wZkp0chq6IwMWAa2N9Ri62Dfz1.png"
                alt="MU:DS - National Museum Goods"
                width={120}
                height={40}
                className="h-8 lg:h-10 w-auto object-contain transition-opacity group-hover:opacity-80"
                priority
              />
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-7">
              {menuItems.map((item) => (
                item.hasCategoryDropdown ? (
                  <div
                    key={item.href}
                    className="relative h-full flex items-center"
                    onMouseEnter={handleCategoryDropdownEnter}
                    onMouseLeave={handleCategoryDropdownLeave}
                  >
                    <Link
                      href={item.href}
                      className={`text-[13px] font-medium tracking-wide transition-colors duration-200 relative group flex items-center gap-0.5 py-1 ${
                        isCategoryDropdownOpen ? "text-foreground" : "text-foreground/70 hover:text-foreground"
                      }`}
                    >
                      {item.label}
                      <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isCategoryDropdownOpen ? "rotate-180" : ""}`} />
                      <span className={`absolute -bottom-0.5 left-0 h-[1.5px] bg-accent transition-all duration-200 ${isCategoryDropdownOpen ? "w-full" : "w-0 group-hover:w-full"}`} />
                    </Link>
                  </div>
                ) : item.hasDropdown ? (
                  <div
                    key={item.href}
                    className="relative h-full flex items-center"
                    onMouseEnter={handleThemeDropdownEnter}
                    onMouseLeave={handleThemeDropdownLeave}
                  >
                    <Link
                      href={item.href}
                      className={`text-[13px] font-medium tracking-wide transition-colors duration-200 relative group flex items-center gap-0.5 py-1 ${
                        isThemeDropdownOpen ? "text-foreground" : "text-foreground/70 hover:text-foreground"
                      }`}
                    >
                      {item.label}
                      <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isThemeDropdownOpen ? "rotate-180" : ""}`} />
                      <span className={`absolute -bottom-0.5 left-0 h-[1.5px] bg-accent transition-all duration-200 ${isThemeDropdownOpen ? "w-full" : "w-0 group-hover:w-full"}`} />
                    </Link>
                  </div>
                ) : (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="text-[13px] font-medium tracking-wide text-foreground/70 hover:text-foreground transition-colors duration-200 relative group py-1"
                  >
                    {item.label}
                    <span className="absolute -bottom-0.5 left-0 w-0 h-[1.5px] bg-accent transition-all duration-200 group-hover:w-full" />
                  </Link>
                )
              ))}
            </nav>

            {/* Category Mega Menu Dropdown */}
            <div
              className={`absolute left-0 right-0 top-full transition-all duration-300 ease-out ${
                isCategoryDropdownOpen
                  ? "opacity-100 visible translate-y-0"
                  : "opacity-0 invisible -translate-y-2 pointer-events-none"
              }`}
              onMouseEnter={handleCategoryDropdownEnter}
              onMouseLeave={handleCategoryDropdownLeave}
            >
              {/* Backdrop */}
              <div className="absolute inset-0 bg-[#faf8f5] border-b border-border/30 shadow-[0_8px_24px_rgba(0,0,0,0.06)]" />
              
              <div className="relative mx-auto max-w-[1400px] px-8 py-6">
                {/* Row 1: 5 categories */}
                <div className="flex border-b border-border/30 pb-5 mb-5">
                  {categoryRow1.map((category, index) => (
                    <div
                      key={category.id}
                      className={`flex-1 px-4 ${index < categoryRow1.length - 1 ? "border-r border-border/30" : ""}`}
                    >
                      <Link
                        href={`/category/${category.id}`}
                        className="text-[13px] font-semibold text-accent mb-3 block hover:text-accent/80 transition-colors"
                      >
                        {category.title}
                      </Link>
                      <ul className="space-y-1.5">
                        {category.items.map((item) => (
                          <li key={item}>
                            <Link
                              href={`/category/${category.id}/${item}`}
                              className="text-[12px] text-foreground/60 hover:text-accent transition-colors relative group inline-block"
                            >
                              {item}
                              <span className="absolute -bottom-0.5 left-0 w-0 h-[1px] bg-accent transition-all duration-200 group-hover:w-full" />
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
                
                {/* Row 2: 5 categories */}
                <div className="flex">
                  {categoryRow2.map((category, index) => (
                    <div
                      key={category.id}
                      className={`flex-1 px-4 ${index < categoryRow2.length - 1 ? "border-r border-border/30" : ""}`}
                    >
                      <Link
                        href={`/category/${category.id}`}
                        className={`text-[13px] font-semibold mb-3 block transition-colors ${
                          category.isSale 
                            ? "text-red-500 hover:text-red-600" 
                            : "text-accent hover:text-accent/80"
                        }`}
                      >
                        {category.title}
                      </Link>
                      {category.items.length > 0 && (
                        <ul className="space-y-1.5">
                          {category.items.map((item) => (
                            <li key={item}>
                              <Link
                                href={`/category/${category.id}/${item}`}
                                className="text-[12px] text-foreground/60 hover:text-accent transition-colors relative group inline-block"
                              >
                                {item}
                                <span className="absolute -bottom-0.5 left-0 w-0 h-[1px] bg-accent transition-all duration-200 group-hover:w-full" />
                              </Link>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Theme Dropdown */}
            <div
              className={`absolute left-0 right-0 top-full transition-all duration-300 ease-out ${
                isThemeDropdownOpen
                  ? "opacity-100 visible translate-y-0"
                  : "opacity-0 invisible -translate-y-2 pointer-events-none"
              }`}
              onMouseEnter={handleThemeDropdownEnter}
              onMouseLeave={handleThemeDropdownLeave}
            >
              {/* Backdrop */}
              <div className="absolute inset-0 bg-background border-b border-border/30" />
              
              <div className="relative mx-auto max-w-[1200px] px-8 py-8">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <span className="text-[11px] tracking-[0.15em] text-accent uppercase font-medium">Curator&apos;s Pick</span>
                    <span className="w-8 h-[1px] bg-border" />
                    <h3 className="text-sm text-foreground font-medium">테마별 굿즈 컬렉션</h3>
                  </div>
                  <Link
                    href="/theme"
                    className="text-[11px] tracking-wide text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"
                  >
                    전체보기
                    <ChevronDown className="w-3 h-3 -rotate-90" />
                  </Link>
                </div>
                
                {/* 2-Row Grid Layout */}
                <div className="flex flex-col items-center gap-6">
                  {/* Row 1: 4 items */}
                  <div className="flex justify-center gap-6">
                    {themeRow1.map((category) => (
                      <Link
                        key={category.id}
                        href={category.href}
                        className="group w-[120px] flex-shrink-0"
                      >
                        {/* Square Image Card — inset -7.5% to crop outer cream margin */}
                        <div className="relative w-[120px] h-[120px] rounded-[20px] overflow-hidden mb-3 transition-all duration-300 ease-out group-hover:shadow-[0_12px_32px_rgba(0,0,0,0.1)] group-hover:scale-[1.03]">
                          <div className="absolute inset-[-7.5%] transition-transform duration-400 ease-out group-hover:scale-[1.06]">
                            <Image
                              src={category.image}
                              alt={category.title}
                              fill
                              className="object-cover"
                              unoptimized
                            />
                          </div>
                          <div className="absolute inset-0 bg-gradient-to-t from-foreground/8 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        </div>
                        
                        <h4 className="text-[13px] font-medium text-foreground mb-1 group-hover:text-accent transition-colors duration-300 text-center">
                          {category.title}
                        </h4>
                        
                        <p className="text-[11px] leading-snug text-muted-foreground/70 group-hover:text-muted-foreground transition-colors duration-300 text-center">
                          {category.description}
                        </p>
                      </Link>
                    ))}
                  </div>
                  
                  {/* Row 2: 3 items (centered) */}
                  <div className="flex justify-center gap-6">
                    {themeRow2.map((category) => (
                      <Link
                        key={category.id}
                        href={category.href}
                        className="group w-[120px] flex-shrink-0"
                      >
                        {/* Square Image Card — inset -7.5% to crop outer cream margin */}
                        <div className="relative w-[120px] h-[120px] rounded-[20px] overflow-hidden mb-3 transition-all duration-300 ease-out group-hover:shadow-[0_12px_32px_rgba(0,0,0,0.1)] group-hover:scale-[1.03]">
                          <div className="absolute inset-[-7.5%] transition-transform duration-400 ease-out group-hover:scale-[1.06]">
                            <Image
                              src={category.image}
                              alt={category.title}
                              fill
                              className="object-cover"
                              unoptimized
                            />
                          </div>
                          <div className="absolute inset-0 bg-gradient-to-t from-foreground/8 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        </div>
                        
                        <h4 className="text-[13px] font-medium text-foreground mb-1 group-hover:text-accent transition-colors duration-300 text-center">
                          {category.title}
                        </h4>
                        
                        <p className="text-[11px] leading-snug text-muted-foreground/70 group-hover:text-muted-foreground transition-colors duration-300 text-center">
                          {category.description}
                        </p>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-4">
              <button className="p-1.5 text-foreground/80 hover:text-foreground transition-colors duration-200" aria-label="검색">
                <Search className="w-[18px] h-[18px]" strokeWidth={1.5} />
              </button>
              <button className="hidden sm:block p-1.5 text-foreground/80 hover:text-foreground transition-colors duration-200" aria-label="위시리스트">
                <Heart className="w-[18px] h-[18px]" strokeWidth={1.5} />
              </button>
              <button className="p-1.5 text-foreground/80 hover:text-foreground transition-colors duration-200 relative" aria-label="장바구니">
                <ShoppingBag className="w-[18px] h-[18px]" strokeWidth={1.5} />
                <span className="absolute top-0 right-0 min-w-[16px] h-4 bg-foreground text-[10px] text-background font-medium flex items-center justify-center px-0.5">
                  0
                </span>
              </button>
              <div className="hidden lg:block w-[1px] h-4 bg-border/50 mx-1" />
              <button
                className="lg:hidden p-1.5 text-foreground/80 hover:text-foreground"
                onClick={() => setIsMobileMenuOpen(true)}
                aria-label="메뉴 열기"
              >
                <Menu className="w-5 h-5" strokeWidth={1.5} />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-[100] transition-opacity duration-300 ${
          isMobileMenuOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
      >
        <div
          className="absolute inset-0 bg-foreground/20 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />
        <div
          className={`absolute top-0 right-0 w-full max-w-sm h-full bg-background transform transition-transform duration-500 ease-out ${
            isMobileMenuOpen ? "translate-x-0" : "translate-x-full"
          }`}
        >
          <div className="flex justify-between items-center h-16 px-6 border-b border-border/50">
            <span className="font-serif text-xl tracking-tight">MU<span className="text-accent">:</span>DS</span>
            <button onClick={() => setIsMobileMenuOpen(false)} aria-label="메뉴 닫기">
              <X className="w-5 h-5" strokeWidth={1.5} />
            </button>
          </div>
          <nav className="p-8 overflow-y-auto max-h-[calc(100vh-64px)]">
            <ul className="space-y-5">
              {menuItems.map((item) => (
                <li key={item.href}>
                  {item.hasDropdown ? (
                    <div>
                      <Link
                        href={item.href}
                        className="text-lg tracking-wide text-foreground hover:text-accent transition-colors flex items-center justify-between"
                        onClick={() => setIsMobileMenuOpen(false)}
                      >
                        {item.label}
                      </Link>
                      <div className="mt-4 grid grid-cols-3 gap-3">
                        {themeCategories.map((category) => (
                          <Link
                            key={category.id}
                            href={category.href}
                            className="flex flex-col items-center gap-2.5 py-2 group"
                            onClick={() => setIsMobileMenuOpen(false)}
                          >
                            <div className="relative w-16 h-12 rounded-[14px] overflow-hidden bg-secondary/30 transition-all duration-300 group-hover:scale-105 group-hover:shadow-[0_6px_16px_rgba(0,0,0,0.1)]">
                              <Image
                                src={category.image}
                                alt={category.title}
                                fill
                                className="object-cover"
                              />
                            </div>
                            <span className="text-[11px] text-muted-foreground group-hover:text-foreground transition-colors text-center font-medium">
                              {category.title}
                            </span>
                          </Link>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <Link
                      href={item.href}
                      className="text-lg tracking-wide text-foreground hover:text-accent transition-colors block"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      {item.label}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
            <div className="mt-10 pt-8 border-t border-border/50">
              <div className="space-y-4 text-sm text-muted-foreground">
                <Link href="/notice" className="block hover:text-foreground">공지사항</Link>
                <Link href="/cs" className="block hover:text-foreground">고객센터</Link>
                <Link href="/login" className="block hover:text-foreground">로그인</Link>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </>
  )
}
