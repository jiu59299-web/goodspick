"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart } from "lucide-react"

const products = [
  {
    id: 1,
    name: "반가사유상 미니어처",
    price: 89000,
    originalPrice: 99000,
    category: "소장품",
    badge: "BEST",
    badgeColor: "bg-[#c4a77d]",
    reviews: 128,
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80",
  },
  {
    id: 2,
    name: "청자운학문 텀블러",
    price: 45000,
    category: "라이프",
    badge: "NEW",
    badgeColor: "bg-foreground",
    reviews: 56,
    image: "https://images.unsplash.com/photo-1544967082-d9d25d867d66?w=600&q=80",
  },
  {
    id: 3,
    name: "단청문양 실크 스카프",
    price: 128000,
    category: "패션",
    badge: "MD추천",
    badgeColor: "bg-[#5a7d6b]",
    reviews: 89,
    image: "https://images.unsplash.com/photo-1596568180553-8f6dc2f0b0d7?w=600&q=80",
  },
  {
    id: 4,
    name: "고려청자 향초 세트",
    price: 68000,
    category: "홈",
    badge: "BEST",
    badgeColor: "bg-[#c4a77d]",
    reviews: 234,
    image: "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=600&q=80",
  },
]

export function ProductGrid() {
  const [isVisible, setIsVisible] = useState(false)
  const [wishlist, setWishlist] = useState<number[]>([])
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.disconnect()
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const toggleWishlist = (id: number) => {
    setWishlist(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    )
  }

  return (
    <section ref={sectionRef} className="py-16 lg:py-24">
      <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
        {/* Section Header */}
        <div className={`mb-10 lg:mb-14 ${isVisible ? "animate-fade-up" : "opacity-0"}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-[11px] tracking-[0.15em] text-accent uppercase font-medium">Best Collection</span>
              <span className="w-8 h-[1px] bg-border" />
              <h2 className="text-lg lg:text-xl font-medium text-foreground">
                큐레이터&apos;s Pick
              </h2>
            </div>
            <Link
              href="/products"
              className="text-[12px] tracking-wide text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5"
            >
              전체보기
              <span className="w-3 h-3 flex items-center justify-center">›</span>
            </Link>
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {products.map((product, index) => (
            <article
              key={product.id}
              className={`group relative ${
                isVisible ? "animate-fade-up opacity-0" : "opacity-0"
              }`}
              style={{
                animationDelay: `${0.2 + index * 0.1}s`,
                animationFillMode: "forwards",
              }}
            >
              <Link href={`/product/${product.id}`} className="block">
                <div className="relative aspect-[4/5] overflow-hidden bg-secondary/50 mb-4">
                  <Image
                    src={product.image}
                    alt={product.name}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    sizes="(max-width: 640px) 50vw, (max-width: 1024px) 50vw, 25vw"
                  />
                  
                  {/* Badge */}
                  {product.badge && (
                    <div className={`absolute top-3 left-3 px-2.5 py-1 ${product.badgeColor} text-[10px] font-medium tracking-wider text-white`}>
                      {product.badge}
                    </div>
                  )}
                  
                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/5 transition-colors duration-300" />
                </div>
              </Link>
              
              {/* Wishlist Button */}
              <button
                onClick={() => toggleWishlist(product.id)}
                className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center bg-white/90 hover:bg-white transition-colors z-10"
                aria-label="위시리스트에 추가"
              >
                <Heart 
                  className={`w-4 h-4 transition-colors ${
                    wishlist.includes(product.id) 
                      ? "fill-[#c4a77d] text-[#c4a77d]" 
                      : "text-foreground/60"
                  }`} 
                  strokeWidth={1.5}
                />
              </button>
              
              {/* Product Info */}
              <div className="space-y-1.5">
                <p className="text-[10px] tracking-[0.15em] text-muted-foreground uppercase">
                  {product.category}
                </p>
                <Link href={`/product/${product.id}`}>
                  <h3 className="text-[14px] font-medium text-foreground group-hover:text-accent transition-colors duration-200 line-clamp-2">
                    {product.name}
                  </h3>
                </Link>
                <div className="flex items-baseline gap-2">
                  <span className="text-[16px] font-semibold text-foreground">
                    {product.price.toLocaleString()}원
                  </span>
                  {product.originalPrice && (
                    <span className="text-[13px] text-muted-foreground line-through">
                      {product.originalPrice.toLocaleString()}원
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-muted-foreground">
                  리뷰 {product.reviews}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
