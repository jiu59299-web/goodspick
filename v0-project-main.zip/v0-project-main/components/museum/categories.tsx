"use client"

import { useEffect, useRef, useState } from "react"
import Link from "next/link"

const categories = [
  { name: "전통", count: 124, href: "/category/traditional" },
  { name: "아트", count: 89, href: "/category/art" },
  { name: "라이프", count: 156, href: "/category/life" },
  { name: "문구", count: 73, href: "/category/stationery" },
  { name: "주얼리", count: 48, href: "/category/jewelry" },
  { name: "홈데코", count: 92, href: "/category/home" },
]

export function Categories() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.disconnect()
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 lg:py-32 border-y border-border/50">
      <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
        {/* Section Header */}
        <div className={`mb-16 lg:mb-20 text-center ${isVisible ? "animate-fade-up" : "opacity-0"}`}>
          <p className="text-xs tracking-[0.3em] text-muted-foreground mb-3 uppercase">
            Categories
          </p>
          <h2 className="font-serif text-3xl lg:text-4xl tracking-tight">
            컬렉션 카테고리
          </h2>
        </div>

        {/* Category Links */}
        <div className="flex flex-wrap justify-center gap-x-8 gap-y-6 lg:gap-x-16 lg:gap-y-8">
          {categories.map((category, index) => (
            <Link
              key={category.name}
              href={category.href}
              className={`group relative ${
                isVisible ? "animate-fade-up opacity-0" : "opacity-0"
              }`}
              style={{
                animationDelay: `${0.2 + index * 0.08}s`,
                animationFillMode: "forwards",
              }}
            >
              <span className="font-serif text-2xl lg:text-3xl tracking-tight text-foreground group-hover:text-accent transition-colors duration-300">
                {category.name}
              </span>
              <span className="ml-2 text-xs text-muted-foreground align-super">
                {category.count}
              </span>
              <span className="absolute -bottom-2 left-0 w-0 h-[1px] bg-accent transition-all duration-300 group-hover:w-full" />
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
