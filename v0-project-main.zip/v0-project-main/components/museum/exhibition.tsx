"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

const exhibitions = [
  {
    id: 1,
    title: "조선의 백자,\n순백의 미학",
    subtitle: "기획전 Vol.12",
    description: "조선 백자의 절제된 아름다움을 현대적 감각으로 재해석한 한정판 컬렉션",
    image: "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?w=1200&q=80",
    href: "/exhibition/1",
  },
  {
    id: 2,
    title: "봄의 정원",
    subtitle: "시즌 컬렉션",
    description: "국립박물관 소장 화조화에서 영감받은 2024 봄 컬렉션",
    image: "https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=1200&q=80",
    href: "/exhibition/2",
  },
]

export function Exhibition() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.disconnect()
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 lg:py-32">
      <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
        {/* Section Header */}
        <div className={`mb-16 lg:mb-20 ${isVisible ? "animate-fade-up" : "opacity-0"}`}>
          <p className="text-xs tracking-[0.3em] text-muted-foreground mb-3 uppercase">
            Special Exhibition
          </p>
          <h2 className="font-serif text-3xl lg:text-4xl tracking-tight">
            기획전 · 이벤트
          </h2>
        </div>

        {/* Exhibition Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
          {exhibitions.map((exhibition, index) => (
            <Link
              key={exhibition.id}
              href={exhibition.href}
              className={`group relative block overflow-hidden ${
                isVisible ? "animate-fade-up opacity-0" : "opacity-0"
              }`}
              style={{
                animationDelay: `${0.2 + index * 0.15}s`,
                animationFillMode: "forwards",
              }}
            >
              <div className="relative aspect-[16/10] lg:aspect-[16/9]">
                <Image
                  src={exhibition.image}
                  alt={exhibition.title.replace("\n", " ")}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent" />
                
                {/* Content Overlay */}
                <div className="absolute inset-0 flex flex-col justify-end p-6 lg:p-10">
                  <p className="text-xs tracking-[0.2em] text-primary-foreground/70 mb-3 uppercase">
                    {exhibition.subtitle}
                  </p>
                  <h3 className="font-serif text-2xl lg:text-3xl text-primary-foreground whitespace-pre-line leading-tight mb-3">
                    {exhibition.title}
                  </h3>
                  <p className="text-sm text-primary-foreground/70 max-w-md mb-6 hidden sm:block">
                    {exhibition.description}
                  </p>
                  <div className="flex items-center gap-2 text-sm text-primary-foreground group-hover:text-accent transition-colors">
                    <span>자세히 보기</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" strokeWidth={1.5} />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
